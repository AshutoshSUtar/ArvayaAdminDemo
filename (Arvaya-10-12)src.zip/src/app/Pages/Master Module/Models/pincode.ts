export class pincode {
    ID: number; 
    STATE_ID
    COUNTRY_ID 
    CLIENT_ID: number; 
    PINCODE;
    IS_ACTIVE: Boolean = true;
}