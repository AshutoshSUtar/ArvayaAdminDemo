export class StateMasterData {
      ID: number = 0;
      NAME: string = '';
    
      STATUS: boolean = true;
      SHORT_CODE:any;
      SEQUENCE_NO: number;
    }

    