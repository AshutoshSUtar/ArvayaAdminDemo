export class CountryData {
  SHORT_CODE: string = "";
  NAME: string = "";
  IS_ACTIVE: boolean = true;
}
