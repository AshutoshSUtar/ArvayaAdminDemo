export class LanguageMasterData
{
  NAME=''
  SHORT_CODE=''
  SEQ_NO :number
  IS_ACTIVE:boolean=true
}
