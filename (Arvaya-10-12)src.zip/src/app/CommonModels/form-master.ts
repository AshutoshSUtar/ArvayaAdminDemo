export class FormMaster {
    ID:number=0;
    NAME:string='';
    LINK:string='';
    PARENT_ID:number=0;
    ICON:string='';
    CLIENT_ID:number=0;
}