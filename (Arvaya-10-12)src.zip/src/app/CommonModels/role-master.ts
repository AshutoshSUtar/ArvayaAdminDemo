export class RoleMaster {
  ID: number = 0;
  NAME: string = '';
  DESCRIPTION: string = '';
  TYPE: string = '';
  PARENT_ID: number = 0;
  CLIENT_ID: number = 0;
  STATUS: any = 1;
  PARENT_NAME:any;
}