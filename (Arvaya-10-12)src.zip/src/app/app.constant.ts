export const appkeys = {
  // local
  gmUrl: 'http://gm.tecpool.in:8079/',
  socketUrl: 'http://pms.tecpool.in:3934',

  // 192.168.178.186 8767
 
  // APIKEY="WGykEs0b241gNKcDshYU9C4I0Ft1JoSb"
   
  // APPLICATION_KEY = 'ZU63HDzj79PEFzz5'
 
  

  // ngrok
  // baseUrl: 'https://7563-2405-201-1011-1857-4d97-8c38-8f0e-42e6.ngrok-free.app//',
  // url: 'https://7563-2405-201-1011-1857-4d97-8c38-8f0e-42e6.ngrok-free.app//api/',
  // imgUrl: 'https://7563-2405-201-1011-1857-4d97-8c38-8f0e-42e6.ngrok-free.app//api/upload/',
  // imgUrl1: 'https://7563-2405-201-1011-1857-4d97-8c38-8f0e-42e6.ngrok-free.app//upload/',
  // retriveimgUrl: 'https://7563-2405-201-1011-1857-4d97-8c38-8f0e-42e6.ngrok-free.app//static/',



  // baseUrl: 'http://192.168.29.186:8767/',
  // url: 'http://192.168.29.186:8767/api/',
  // imgUrl: 'http://192.168.29.186:8767/api/upload/',
  // imgUrl1: 'http://192.168.29.186:8767/api/upload/',
  // retriveimgUrl: 'http://192.168.29.186:8767/static/',

  baseUrl: 'http://192.168.178.186:8767/',
  url: 'http://192.168.178.186:8767/api/',
  imgUrl: 'http://192.168.178.186:8767/api/upload/',
  imgUrl1: 'http://192.168.178.186:8767/api/upload/',
  retriveimgUrl: 'http://192.168.178.186:8767/static/',

  // baseUrl: 'http://pockitadmin.uvtechsoft.com:8767/',
  // url: 'http://pockitadmin.uvtechsoft.com:8767/api/', 
  // imgUrl: 'http://pockitadmin.uvtechsoft.com:8767/api/upload/', 
  // imgUrl1: 'http://pockitadmin.uvtechsoft.com:8767/api/upload/', 
  // retriveimgUrl: 'http://pockitadmin.uvtechsoft.com:8767/static/', 
};
